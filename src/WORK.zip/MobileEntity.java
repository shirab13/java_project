package game.entities;

import utilities.Point;

public abstract class MobileEntity extends Entity {
    protected double maxSpeed;
    protected double acceleration;
    protected double speed;

    public MobileEntity(double maxSpeed, double acceleration) {
        super(new Point(0, 0));
        this.maxSpeed = maxSpeed;
        this.acceleration = acceleration;
        this.speed = 0;
    }

    public double getMaxSpeed() {
        return maxSpeed;
    }

    public double getAcceleration() {
        return acceleration;
    }

    public double getSpeed() {
        return speed;
    }

    public void setSpeed(double speed) {
        this.speed = speed;
    }

    public abstract void move(double friction);

    @Override
    public String toString() {
        return "MobileEntity{" +
                "maxSpeed=" + maxSpeed +
                ", acceleration=" + acceleration +
                ", speed=" + speed +
                ", location=" + location +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;

        MobileEntity that = (MobileEntity) o;

        if (Double.compare(that.maxSpeed, maxSpeed) != 0) return false;
        if (Double.compare(that.acceleration, acceleration) != 0) return false;
        return Double.compare(that.speed, speed) == 0;
    }
}
