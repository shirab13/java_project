package game.entities.sportsman;

import game.competition.Competitor;
import game.enums.Discipline;
import game.enums.Gender;
import game.enums.League;
import utilities.ValidationUtils;

public abstract class WinterSportsman extends Competitor {
    protected String name;
    protected int age;
    protected Gender gender;
    protected Discipline discipline;
    protected League league;

    public WinterSportsman(String name, int age, Gender gender, double maxSpeed, double acceleration, Discipline discipline) {
        super(maxSpeed, acceleration);
        ValidationUtils.validateStringNotEmpty(name, "Name cannot be empty");
        ValidationUtils.validatePositive(age, "Age must be positive");
        ValidationUtils.validateNotNull(gender, "Gender cannot be null");
        ValidationUtils.validateNotNull(discipline, "Discipline cannot be null");

        this.name = name;
        this.age = age;
        this.gender = gender;
        this.discipline = discipline;
        this.league = determineLeague(age);
    }

    private League determineLeague(int age) {
        if (age <= 16) {
            return League.JUNIOR;
        } else if (age <= 30) {
            return League.ADULT;
        } else {
            return League.SENIOR;
        }
    }

    public Discipline getDiscipline() {
        return discipline;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public Gender getGender() {
        return gender;
    }

    public League getLeague() {
        return league;
    }

    @Override
    public abstract void move(double friction);

    @Override
    public String toString() {
        return "WinterSportsman{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", gender=" + gender +
                ", discipline=" + discipline +
                ", league=" + league +
                ", maxSpeed=" + maxSpeed +
                ", acceleration=" + acceleration +
                ", speed=" + speed +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        WinterSportsman that = (WinterSportsman) o;

        if (age != that.age) return false;
        if (Double.compare(that.maxSpeed, maxSpeed) != 0) return false;
        if (Double.compare(that.acceleration, acceleration) != 0) return false;
        if (Double.compare(that.speed, speed) != 0) return false;
        if (!name.equals(that.name)) return false;
        if (gender != that.gender) return false;
        if (discipline != that.discipline) return false;
        return league == that.league;
    }
}
