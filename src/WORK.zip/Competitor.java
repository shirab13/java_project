package game.competition;

import game.entities.IMobileEntity;
import game.entities.MobileEntity;
import utilities.Point;

public abstract class Competitor extends MobileEntity implements IMobileEntity {

    public Competitor(double maxSpeed, double acceleration) {
        super(maxSpeed, acceleration);
    }

    public void initRace(Point start) {
        this.location = start;
        this.speed = 0;
    }

    @Override
    public abstract void move(double friction);

    public String getName() {
        return getClass().getSimpleName();
    }

    @Override
    public String toString() {
        return "Competitor{" +
                "maxSpeed=" + maxSpeed +
                ", acceleration=" + acceleration +
                ", speed=" + speed +
                ", location=" + location +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Competitor that = (Competitor) o;

        if (Double.compare(that.maxSpeed, maxSpeed) != 0) return false;
        if (Double.compare(that.acceleration, acceleration) != 0) return false;
        if (Double.compare(that.speed, speed) != 0) return false;
        return location.equals(that.location);
    }
}
