package game.entities.sportsman;

import game.enums.Gender;
import game.entities.MobileEntity;
import utilities.ValidationUtils;

public abstract class Sportsman extends MobileEntity {
    protected String name;
    protected double age;
    protected Gender gender;

    public Sportsman(String name, double maxSpeed, double age, double acceleration, Gender gender) {
        super(maxSpeed, acceleration);
        ValidationUtils.validateStringNotEmpty(name, "Name cannot be empty");
        ValidationUtils.validatePositive(age, "Age must be positive");
        ValidationUtils.validateNotNull(gender, "Gender cannot be null");

        this.name = name;
        this.age = age;
        this.gender = gender;
    }


    public String getName() {
        return name;
    }

    public double getAge() {
        return age;
    }

    public Gender getGender() {
        return gender;
    }
}
